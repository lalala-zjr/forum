import Vue from 'vue'

var password = new Vue()
export default password
